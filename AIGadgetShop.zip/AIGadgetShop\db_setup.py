import pymysql

def setup_database():
    try:
        # Pehle connection banate hain bina database select kiye
        conn = pymysql.connect(
            host="127.0.0.1",
            user="root",
            password="12345678"
        )
        cursor = conn.cursor()

        # Database create karte hain
        cursor.execute("CREATE DATABASE IF NOT EXISTS MyAIGadgetShop")
        cursor.execute("USE MyAIGadgetShop")

        # Smartphones table
        cursor.execute("DROP TABLE IF EXISTS Smartphones")
        cursor.execute("""
        CREATE TABLE Smartphones (
            id INT PRIMARY KEY AUTO_INCREMENT,
            name VARCHAR(100),
            brand VARCHAR(50),
            price INT,
            stock VARCHAR(20),
            warranty VARCHAR(50),
            color varchar(50)
        )
        """)
        
        smartphones_data = [
            ('Samsung Galaxy S23 Ultra', 'Samsung', 320000, 'Available', 'black', '1 Year Official'),
            ('Samsung Galaxy S22 Plus', 'Samsung', 185000, 'Available', 'white', '1 Year'),
            ('Samsung Galaxy Z Fold 5', 'Samsung', 550000, 'Available', 'black','1 Year Official'),
            ('Samsung Galaxy Z Flip 5', 'Samsung', 280000, 'Available', 'gray', '1 Year Official'),
            ('Samsung Galaxy A73', 'Samsung', 145000, 'Available', 'white', '1 Year'),
            ('Samsung Galaxy A54', 'Samsung', 125000, 'Available', 'brown', '1 Year Official'),
            ('Samsung Galaxy A34', 'Samsung', 95000, 'Available', 'black', '1 Year'),
            ('Samsung Galaxy A24', 'Samsung', 72000, 'Available', 'blue', '1 Year'),
            ('Samsung Galaxy M34', 'Samsung', 65000, 'Available', 'black', 'No Warranty'),
            ('Samsung Galaxy F54', 'Samsung', 88000, 'Out of Stock', 'white', '1 Year')
        ]
        cursor.executemany("INSERT INTO Smartphones (name, brand, price, stock, color, warranty) VALUES (%s, %s, %s, %s, %s, %s)", smartphones_data)

        # Accessories table
        cursor.execute("DROP TABLE IF EXISTS Accessories")
        cursor.execute("""
        CREATE TABLE Accessories (
            id INT PRIMARY KEY AUTO_INCREMENT,
            name VARCHAR(100),
            brand VARCHAR(50),
            price INT,
            stock VARCHAR(20),
            warranty VARCHAR(50),
            color varchar(50)
        )
        """)
        accessories_data = [
            ('Fast Charger 25W', 'Samsung', 4500, 'Available', 'white', '6 Months'),
            ('USB Type-C Cable', 'Anker', 1200, 'Available',  'black','1 Year'),
            ('Power Bank 20000mAh', 'Belkin', 5500, 'Available', 'black', '1 Year'),
            ('Wired Earphones', 'Apple', 6500, 'Available', 'white', '1 Year Official'),
            ('Wireless Earbuds', 'Ronin', 2200, 'Available', 'black', '6 Months'),
            ('Mobile Cover', 'Generic', 1500, 'Available', 'black,white,gray,blue', 'No Warranty'),
            ('Wall Charger 18W', 'Baseus', 450, 'Available',  'black','No Warranty'),
            ('Car Charger Dual Port', 'Ugreen', 1800, 'Available', 'gray', '3 Months'),
            ('Wireless Headphones', 'Joyroom', 5200, 'Out of Stock', 'black', '6 Months'),
            ('Screen Protector Tempered Glass', 'Razer', 3800, 'Available', 'black', '1 Year')
        ]
        cursor.executemany("INSERT INTO Accessories (name, brand, price, stock, color, warranty) VALUES (%s, %s, %s, %s, %s, %s)", accessories_data)

        # SmartGadgets table
        cursor.execute("DROP TABLE IF EXISTS SmartGadgets")
        cursor.execute("""
        CREATE TABLE SmartGadgets (
            id INT PRIMARY KEY AUTO_INCREMENT,
            name VARCHAR(100),
            brand VARCHAR(50),
            price INT,
            stock VARCHAR(20),
            battery_life VARCHAR(50),
            color varchar(50)
        )
        """)
        gadgets_data = [
            ('Smart Watch', 'Apple', 125000, 'Available', 'black','18 Hours'),
            ('Bluetooth Speaker', 'Samsung', 75000, 'Available', 'black', '40 Hours'),
            ('Fitness Band', 'Xiaomi', 9500, 'Available', 'gray', '16 Days'),
            ('Fitness Band Pro', 'Audionic', 12000, 'Available', 'blue', '6 Hours'),
            ('AirPods (Original)', 'Generic', 8500, 'Out of Stock','black','4 Days'),
            ('Smart Glasses Basic', 'Tanix', 6500, 'Available','brown', 'Constant Power'),
            ('Mini Smart Camera', 'Xiaomi', 8800, 'Available','black', 'Constant Power'),
            ('AirPods (Copy)', 'Philips', 4200, 'Available', 'white', 'No Battery'),
            ('Smart Table Lamp', 'Generic', 1200, 'Available', 'black', '3 Hours'),
            ('Digital Smart Scale', 'Huawei', 5500, 'Available', 'blue', '1 Year Battery')
        ]
        cursor.executemany("INSERT INTO SmartGadgets (name, brand, price, stock, color, battery_life) VALUES (%s, %s, %s, %s, %s, %s)", gadgets_data)

        conn.commit()
        print("Database MyAIGadgetShop aur tables kamyabi se ban gaye hain!")
        conn.close()

    except pymysql.MySQLError as err:
        print(f"Error: {err}")
        print("Kya apka XAMPP/MySQL server start hai?")

if __name__ == "__main__":
    setup_database()
