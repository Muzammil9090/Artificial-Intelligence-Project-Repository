AIGadgetShop Project Instructions
===============================

Folder Location:
This folder contains all your project files: Backend, Frontend, and Database scripts.

How to Run (For Demo/Showcase):
-------------------------------
1. Double-click "run_bot.bat".
   - This will start the server (`python app.py`) AND open the website automatically.
   - You don't need to type any commands.

2. If Database is missing or empty:
   - Double-click "reset_db.bat".
   - This will recreate the database and tables.

How to Open in VS Code:
-----------------------
1. Open VS Code.
2. Go to File > Open Folder.
3. Select this "AIGadgetShop" folder.
4. You will see all files (app.py, templates/index.html, etc.) on the left side.

Files Included:
---------------
- app.py                (Backend - Python/Flask)
- db_setup.py           (Database Setup - SQL)
- templates/index.html  (Frontend - HTML/CSS/JS)
- requirements.txt      (Library Dependencies)
- run_bot.bat           (Shortcut to run project)
- reset_db.bat          (Shortcut to fix database)

Good luck with your presentation! 🚀
