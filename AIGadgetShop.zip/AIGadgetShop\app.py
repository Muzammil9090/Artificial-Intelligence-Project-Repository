import pymysql
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from fuzzywuzzy import process

app = Flask(__name__)
CORS(app)

def get_db_connection():
    try:
        return pymysql.connect(
            host="127.0.0.1",
            user="root",
            password="12345678", 
            database="MyAIGadgetShop",
            cursorclass=pymysql.cursors.DictCursor
        )
    except Exception as e:
        print(f"Database Connection Error: {e}")
        return None

def search_product(cursor, user_msg):
    tables = ["Smartphones", "Accessories", "SmartGadgets"]
    
    # Pehle saare products fetch karte hain
    all_products = []
    
    for table in tables:
        if table == "SmartGadgets":
            query = f"SELECT name, price, stock, color, battery_life as extra_info FROM {table}"
        else:
            query = f"SELECT name, price, stock, color, warranty as extra_info FROM {table}"
            
        cursor.execute(query)
        items = cursor.fetchall()
        for item in items:
            item['category'] = table
            all_products.append(item)
    
    # Ab fuzzy matching karte hain
    if not all_products:
        return None
        
    product_names = [p['name'] for p in all_products]
    
    # user_msg mein se behtareen match dhundte hain
    # extractOne returns a tuple: (best_match_string, score)
    best_match, score = process.extractOne(user_msg, product_names)
    
    # Agar match score acha hai (e.g. > 55), to hum us item ko return karte hain
    if score > 55:
        return next((p for p in all_products if p['name'] == best_match), None)
            
    return None

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chatbot', methods=['POST'])
def chatbot():
    data = request.json
    user_msg = data.get("message", "").lower()
    
    db = get_db_connection()
    if not db:
        return jsonify({"reply": "Database connect nahi ho raha! Please make sure XAMPP/MySQL running hai."})
    
    cursor = db.cursor()
    
    # Product dhundte hain
    product = search_product(cursor, user_msg)

    if product:
        name = product['name']
        price = product['price']
        stock = product['stock']
        color = product['color']
        extra = product['extra_info'] # Warranty or Battery Life
        
        # Default response with full details
        reply = f"Ji, {name} hamare paas {stock} hai. Iski price {price} PKR hai. Available colors: {color}. (Warranty/Battery: {extra})"

        # Specific questions handling
        if "price" in user_msg or "kitne" in user_msg or "rate" in user_msg:
            reply = f"{name} ki price {price} PKR hai."
        elif "stock" in user_msg or "available" in user_msg:
            reply = f"{name} filhal {stock} hai."
        elif "color" in user_msg or "rank" in user_msg:
            reply = f"{name} in rangon mein dastayaab hai: {color}."
        elif "warranty" in user_msg or "waranti" in user_msg:
            reply = f"{name} ki warranty/battery status: {extra}."
            
    else:
        reply = "Maaf kijiyega, mere paas iski maloomat nahi hai. Kya aap kisi aur cheez ke bare mein poochna chahenge?"

    db.close()
    return jsonify({"reply": reply})

if __name__ == '__main__':
    print("Chatbot start ho raha hai...")
    # Debug mode disabled for stability in this environment
    app.run(debug=False, port=5000)
