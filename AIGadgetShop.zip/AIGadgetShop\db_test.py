import mysql.connector
import sys

print("Testing database connection...", flush=True)

try:
    conn = mysql.connector.connect(
        host="127.0.0.1",
        user="root",
        password="12345678"
    )
    if conn.is_connected():
        print("Connected to MySQL successfully!", flush=True)
        conn.close()
    else:
        print("Connection failed without error?", flush=True)
        
except Exception as e:
    print(f"Connection failed with error: {e}", flush=True)
